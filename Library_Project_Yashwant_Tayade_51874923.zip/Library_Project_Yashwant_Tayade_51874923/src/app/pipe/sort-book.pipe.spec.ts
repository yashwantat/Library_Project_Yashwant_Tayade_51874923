import { SortBookPipe } from './sort-book.pipe';

describe('SortBookPipe', () => {
  it('create an instance', () => {
    const pipe = new SortBookPipe();
    expect(pipe).toBeTruthy();
  });
});
